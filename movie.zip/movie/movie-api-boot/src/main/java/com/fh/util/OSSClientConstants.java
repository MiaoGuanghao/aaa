package com.fh.util;

public class OSSClientConstants {
 //阿里云API的外网域名
 public static final String ENDPOINT = "http://oss-cn-qingdao.aliyuncs.com";
 //阿里云API的密钥Access Key ID
 public static final String ACCESS_KEY_ID = "LTAI4FqAyjEUPBmNcR8ceDv3";
 //阿里云API的密钥Access Key Secret
 public static final String ACCESS_KEY_SECRET = "PBEJg2LKUktRQC5I34GmBkyvBaFawr";
 //阿里云API的bucket名称
 public static final String BACKET_NAME = "xueya0923";
 //阿里云API的文件夹名称
 public static final String FOLDER="ossimg/";
}
