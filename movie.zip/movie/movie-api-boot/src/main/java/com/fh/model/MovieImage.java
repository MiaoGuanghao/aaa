package com.fh.model;

import lombok.Data;

@Data
public class MovieImage {
 private Integer id;
 private String image;
 private Integer movieId;
}
