package com.fh.common;

public class AjaxException extends   RuntimeException {

}
