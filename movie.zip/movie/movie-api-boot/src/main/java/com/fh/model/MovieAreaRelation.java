package com.fh.model;

import lombok.Data;

@Data
public class MovieAreaRelation {
 private Integer id;
 private Integer areaId;
 private Integer movieId;
}
