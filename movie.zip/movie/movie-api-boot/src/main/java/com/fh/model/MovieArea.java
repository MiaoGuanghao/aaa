package com.fh.model;

import lombok.Data;

import java.util.Date;

@Data
public class MovieArea {
 private Integer id;
 private String name;
 private Date creaTime;
 private Date updateTime;
}
