package com.fh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieApiBootApplicationTests {

 @Test
 void contextLoads() {
 }

}
